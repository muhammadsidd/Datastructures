#ifndef CALCLIST_C
#define CALCLIST_C
#include "CalcList.hpp"
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include "Node.hpp"
#include "List.hpp"

using namespace std;
double CalcList::total()const{

if(CalcList::clist->empty()){
    return 0;
}
else{    
return CalcList::clist->front();
}
}
void CalcList::newOperation(const FUNCTIONS func, const double operand){
   double total = CalcList::total(); //variable to hold the total 
   double oper = operand;              //varibale holding operand
    switch (func){  //switch cases for desired enum to make the code more readable 

        case ADDITION: total = CalcList::total() + operand; //total added to operand 
        CalcList::op = '+'; //addition has operator + stored
        CalcList::clist->addFront(total, op, oper);
        break;

        case SUBTRACTION: total = CalcList::total() - operand;  //operand subtracted from the total
        CalcList::op = '-'; //operator stored for subtraction in nodes
        CalcList::clist->addFront(total,op,oper);   //attach node to the front of the list
        break;

        case MULTIPLICATION: total = CalcList::total()*operand; //multiplicaion operation
        CalcList::op = '*'; //change opererator to *
        CalcList::clist->addFront(total,op, oper); //attach to the front of the node
        break;

        case DIVISION: 
         CalcList::op='/';
            if(operand !=0){    //if statement implemented for throwing a zero divide error 
                total = CalcList::total() / operand;    //operation
                CalcList::clist->addFront(total, op, oper); //attach new total to the front of the list
            }
            else {
                 throw "cannot be divided by 0";    //throw zero divide
            }
        break; 
    }
    
}
void CalcList::removeLastOperation(){
    if(CalcList::clist->empty()){
         throw "list is empty";     //empty list should throw 
    }
    else{
    CalcList::clist->removeFront();     //undo the operation should remove the last one. 
    }
}
std::string CalcList::toString(unsigned short precision)const{
    if (CalcList::clist== nullptr){ //empty list should return empty string 
        return " ";
    }
    Node* temp = CalcList::clist->head; //pointer to the start of the list
    string line;                //holds the string 
    stringstream ss;            //string stream to conver the operations into a string variable 
    ss <<setprecision(precision)<<fixed;
    int count=1;
    while (temp->next != nullptr)   //exit the loop when the temp reaches the end of the list
    {
        Node* n = temp;
        ss<< count<< ": " << n->elem << n->opp <<n->operand <<"="<< n->next->elem<<"\n";    
        temp = temp->next;  //incremeant to the next node 
        count++;
    }
    line = ss.str(); //convert to string
    return line;        //return that string 
;
    
}




#endif