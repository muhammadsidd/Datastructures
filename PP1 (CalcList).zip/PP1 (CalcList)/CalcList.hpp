#ifndef CALCLIST_H
#define CALCLIST_H
#include "List.hpp"
#include "Node.hpp"
#include "CalcListInterface.hpp"
#include <string>
#include<sstream>
#include <iomanip>

class CalcList : public CalcListInterface //inheriting the given base class 
{

public:

double total()const override; 
void newOperation(const FUNCTIONS func, const double operand)override;
void removeLastOperation()override;
std::string toString(unsigned short precision)const override;

private:
char op;
List* clist = new List;

};
#endif
