#ifndef LIST_C
#define LIST_C
#include "List.hpp"
#include <string>



List::List():head(NULL){

}


List:: ~List(){
    while (!empty()){
        removeFront(); //remove the head -> undo the last operation 
    }
}


bool List::empty () const{
return head == NULL;    //check if the list is empty 
}

const double& List::front(){
return head-> elem;     //holds and return the front element 
}


void List::addFront (const double& e, char& c, double& o){
Node* v = new Node;  /*create new node and add that new node, store its respective item
                    and attach it to the front of the list */
v->elem = e;
v->opp = c;
v->operand = o;
v->next = head;
head = v;
}

void List::removeFront(){
Node* old = head;               //removing the front node
head = old->next;
delete old;
}

#endif