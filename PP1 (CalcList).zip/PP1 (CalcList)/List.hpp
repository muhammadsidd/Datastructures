#ifndef LIST_H
#define LIST_H
#include <string>
#include "Node.hpp"

class List{



public:
List();
~List();
bool empty () const;
const double& front();
void addFront (const double& e, char& c, double& o);
void removeFront();
Node* head;
};

#endif