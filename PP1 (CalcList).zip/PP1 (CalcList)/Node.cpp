#ifndef NODE_C
#define NODE_C
#include <string>


class Node {

public:
double operand; //holds operand given by the professor 
double elem;    //element or the total (begins with 0)
char opp;       //opearation chosen from enum
Node* next;     //pointer to the next node
friend class List;  //to access the private members 

};

#endif