#ifndef NODE_H
#define NODE_H
#include <string>


class Node {

public:
double operand;
double elem;
char opp;
Node* next;
friend class List;

};

#endif