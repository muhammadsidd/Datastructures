/*Author: Muhammad Siddiqui
The following program deals with notion conversion, it takes in a string of variables and converts it depending upon the precedence of the notation.
The program uses a doubly linked list for this data structure */

#include "NotationConverter.hpp"

//Contructor that initializes the header and trailer of doubly linked list
DLinkedList::DLinkedList()
{
	header = new DNode;
	trailer = new DNode;
	header->next = trailer;
	trailer->prev = header;
}

//Destructor for the dynamically stored data
DLinkedList::~DLinkedList()
{
	while (!empty()) {
		removeFront();
	}
	delete header;
	delete trailer;
}

//to check if the list is empty 
bool DLinkedList::empty() const
{
	return (header->next == trailer);
}
//return first data of the linked list
const string DLinkedList::front() const
{
	return (header->next->data);
}
//end of the list
const string DLinkedList::back() const
{
	return (trailer->prev->data);
}
//add to the list and point the header to it, top of the list
void DLinkedList::addFront(const string e)
{
	add(header->next, e);
}
//add to the list and this points to the tail of the list , LAST NODE
void DLinkedList::addBack(const string e)
{
	add(trailer, e);
}
//delete first node
void DLinkedList::removeFront()
{
	remove(header->next);
}
//delete last node 
void DLinkedList::removeBack()
{
	remove(trailer->prev);
}
//add to the desired node
void DLinkedList::add(DNode* v, const string e)
{
	DNode* temp = new DNode; 
	temp->data = e;
	temp->next = v;
	temp->prev = v->prev;
	v->prev->next = temp;
	v->prev = temp;
}

void DLinkedList::remove(DNode* v)
{
	DNode* temp1 = v->prev; 
	DNode* temp2 = v->next;
	temp1->next = temp2;
	temp2->prev = temp1;
	delete v;
}
//checks the precendece of the string data passed to it
int NotationConverter::rank(string c) 
{
	if (c == "*" || c == "/")
		return 1;
	else if (c == "+" || c == "-")
		return 0;
	else
		return -1;
}
//varifies that the string is alphabetic characters 
bool NotationConverter::isvalid(string c) 
{ 
	
	for (int i = 0; i < c.length(); i++) {
		if ((!isalpha(c[i])) && (c[i] != ' ') && (c[i] != '(') 
			&& (c[i] != ')') && (c[i] != '+') && (c[i] != '-') 
			&& (c[i] != '*') && (c[i] != '/')) {
			return true;
		}
	}
	return false;

}

string NotationConverter::postfixToInfix(string inStr)
{
		if (isvalid(inStr)) {
		throw inStr;		//throw exception if not valid 
		}

		string inFixString;		//declare a variable to hold the converted string 
		DLinkedList list;

	

	for (int i = 0; i < inStr.length(); i++) {
		char inputstring = inStr[i];		//invidiual characters added to the array on string 
		string input;
		input += inputstring;				//individual characters are grouped 

		if (isalpha(inputstring)) {
			list.addFront(input);		//add to the linked list 
		}
		else if (inputstring == ' ') {
			continue;			//skip iteration if the white space is met 
		}
		else {
			string buffer1 = list.front();
			list.removeFront();
			string buffer2 = list.front();
			list.removeFront();
			list.addFront("(" + buffer2 + " " + input + " " + buffer1 + ")");
		}
	}

	inFixString = list.front();

	return inFixString;
}

string NotationConverter::infixToPrefix(string inStr)
{
	if (isvalid(inStr)) {
		throw inStr;
	}

	string preFixString;
	DLinkedList temp1;
	DLinkedList list;
	
	

	reverse(inStr.begin(), inStr.end());

	for (int i = 0; i < inStr.length(); i++) {
		char in = inStr[i];
		string input;
		input += in;
		if (isalpha(in)) {
			temp1.addFront(input);
			temp1.addFront(" ");
		}
		else if (in == '(') {
			while (list.front() != ")")
			{
				temp1.addFront(list.front());
				temp1.addFront(" ");
				list.removeFront();
			}
			if (list.front() == ")")
			{
				list.removeFront();
			}
		}
		else if (in == ')') {
			list.addFront(input);
		}
		else if (in == ' ') {
		}
		else {
			if (!list.empty()) {
				while (rank(input) < rank(list.front())) {
					temp1.addFront(list.front());
					temp1.addFront(" ");
					list.removeFront();
				}
				list.addFront(input);
			}
			else {
				list.addFront(input);
			}
		}
	}

	while (!list.empty())
	{
		temp1.addFront(list.front());
		temp1.addFront(" ");
		list.removeFront();
	}
	
	temp1.removeFront();

	while (!temp1.empty()) {
		preFixString += temp1.front();
		temp1.removeFront();
	}
	return preFixString;
}

string NotationConverter::prefixToPostfix(string inStr)
{	
	if (isvalid(inStr)) {
		throw inStr;
	}

	string postFixString;
	DLinkedList temp;
	DLinkedList list;

	

	reverse(inStr.begin(), inStr.end());

	for (int i = 0; i < inStr.length(); i++) {
		char group = inStr[i];
		string input;
		input += group;

		if (isalpha(group)) {
			list.addFront(input);
		}
		else if (group == ' ') {
			continue;
		}
		else {
			string temp1 = list.front();
			list.removeFront();
			string temp2 = list.front();
			list.removeFront();
			list.addFront(temp1 + " " + temp2 + " " + input);
		}
	}

	postFixString = list.front();
	return postFixString;
}
//since functions for infix, prefix and postfix are already made following operations can be shuffled and converted

string NotationConverter::postfixToPrefix(string inStr)
{
	string preFixString;
	string convertToPrefix;

	convertToPrefix = postfixToInfix(inStr);		//convert to infix 
	preFixString = infixToPrefix(convertToPrefix);	//convert infix to prefix 

	return preFixString;
}

string NotationConverter::infixToPostfix(string inStr)
{
	string postFixString;
	string convert;
	
	convert = infixToPrefix(inStr);
	postFixString = prefixToPostfix(convert);
	return postFixString;
}
string NotationConverter::prefixToInfix(string inStr)
{
	string inFixString;
	string convert;

	convert = prefixToPostfix(inStr);
	inFixString = postfixToInfix(convert);
	return inFixString;
}
