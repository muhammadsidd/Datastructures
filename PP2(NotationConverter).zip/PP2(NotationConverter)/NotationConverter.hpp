#ifndef NOTATIONCONVERTER_H
#define NOTATIONCONVERTER_H

#include <iostream>
#include <string>
#include <ctype.h>
#include <algorithm>
#include "NotationConverterInterface.hpp"

using namespace std;

//Default constructor is already created when new operator is used to create new SNode object
class DNode {
private:
	string data;
	DNode* next;
	DNode* prev;
	friend class DLinkedList;

};

class DLinkedList { 
	DLinkedList(); 
	~DLinkedList();
	bool empty() const; 
	const string front() const; 
	const string back() const; 
	void addFront(const string e); 
	void addBack(const string e); 
	void removeFront(); 
	void removeBack(); 
	void add(DNode* v, const string e); 
	void remove(DNode* v);
private:
	DNode* header; 
	DNode* trailer;
	friend class NotationConverter;
};

class NotationConverter: public NotationConverterInterface{ //Inheriting from NotationConverterInterface
public:
	int rank(string c);
	bool isvalid(string c);

	string postfixToInfix(string inStr);
	string postfixToPrefix(string inStr);

	string infixToPostfix(string inStr);
	string infixToPrefix(string inStr);

	string prefixToInfix(string inStr);
	string prefixToPostfix(string inStr);
};

#endif