#include "GritVM.hpp"
#include <fstream>
GritVM::GritVM(){

    machineStatus = WAITING;
    accumulator =0;

}
/*LOAD THE GIVEN GRITVM FILE RESPECTIVELY  */
STATUS GritVM::load(const std:: string filename, const std::vector<long>&initialMemory){
	reset();		//open file 
	ifstream bruh;
    bruh.open(filename);

    if(bruh.fail()){	//display error if file not opened 
        throw "Error opening file";
    }
    while (!bruh.eof())			//read file evry line 
    {   string line;
		getline(bruh, line); 	
			if(line =="" || line[0]=='#'){		//skipcondition for # and empty line  
                continue;
            }
                Instruction ins = parseInstruction(line); //pass the line to professor initiated method to seperate oeration & arguments 

           if(ins.operation != UNKNOWN_INSTRUCTION){	//fill the instruction list 
               instructMem.push_back(ins);
            }

           else{
               machineStatus = ERRORED; //Error envountered and then reset 
               reset();
               return machineStatus;
           }
    }

    if(instructMem.size() != 0){
        machineStatus = READY;

    }
    else{
        machineStatus = WAITING;
    }

			
    dataMem = initialMemory;	//copy initial mem to data memory 
    bruh.close();	//save file 
    return machineStatus;	//return 
} 

/*RUN THE GRITVM DEPENDING ON THE INSTRUCTION SET OF THE VECTOR OPERATIONS AND STRUCT INSTRUCTIONS  */
STATUS GritVM::run(){

    if(machineStatus == READY){
        currentInstruct = instructMem.begin();
        machineStatus = RUNNING;
    
        do{
			long jumpDistance = evaluate(*currentInstruct); //gets the respective operation and jumps given instructions 
			
			    if (jumpDistance == 1){		//jump condition = jump 1 instrcution further  
                currentInstruct++;
                }
                else if (jumpDistance < 1){	//revind given instruction 
                    for(int i =0; i > jumpDistance; i--){
                    currentInstruct--;
                    }
                }
                else if (jumpDistance > 1){	//forward given instuctions 
                    for (int i=0; i < jumpDistance ; i++){
                    currentInstruct++;
                    }
                }
                else {
                    throw "Error has occured or reached the end";
                    machineStatus = ERRORED;	//Error display when instrcutions end or error encountered 
                }
                
                if (currentInstruct->operation == HALT) { 
					machineStatus = HALTED;			//when operations is hault set machine status to hault 
				break;
			    }

	    } while (machineStatus == RUNNING && currentInstruct != instructMem.end());	//continue the loop until end of instruction set 

    }
	    if (currentInstruct == instructMem.end()) {
		    machineStatus = HALTED;	//hault at the end 
	    }

	    return machineStatus;		

}
/*EVALUATE THE INSTRUCTIONS DEPENDING ON THE ARGUMENT AND OPERATION AND SET THE JUMP VALUE TO RESPECTIVE INSTRUCTON - RETURN JUMPED INSTUCTION */
long GritVM::evaluate(Instruction ins){
    
    long jumpDist;

switch (ins.operation) {

	case CLEAR:
		accumulator = 0;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case AT:
		accumulator = dataMem.at(ins.argument);
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case SET:
		dataMem.at(ins.argument) = accumulator;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case INSERT:
		dataMem.insert(dataMem.begin() + ins.argument, accumulator); //jump x locations from beginning of the list 
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case ERASE:
		dataMem.erase(dataMem.begin() + ins.argument); //erase x location from beginng of the list 
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case ADDCONST:
		accumulator += ins.argument;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case SUBCONST:
		accumulator -= ins.argument;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case MULCONST:
		accumulator *= ins.argument;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case DIVCONST:
		accumulator /= ins.argument;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case ADDMEM:
		accumulator += dataMem.at(ins.argument);
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case SUBMEM:
		accumulator -= dataMem.at(ins.argument);
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case MULMEM:
		accumulator *= dataMem.at(ins.argument);
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case DIVMEM:
		accumulator /= dataMem.at(ins.argument);
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case JUMPREL:
		jumpDist = ins.argument;
		machineStatus = RUNNING;
		break;
	case JUMPZERO:
		if (accumulator == 0) {
			jumpDist = ins.argument;
		}
		else {
			jumpDist = 1;
		}
		machineStatus = RUNNING;
		break;
	case JUMPNZERO:
		if (accumulator != 0) {
			jumpDist = ins.argument;
		}
		else {
			jumpDist = 1;
		}
		machineStatus = RUNNING;
		break;
	case NOOP:
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case HALT:
		machineStatus = HALTED;
		jumpDist = 1;
		break;
	case OUTPUT:
		cout << accumulator << endl;
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	case CHECKMEM:
		if (dataMem.size() < ins.argument) {
			machineStatus = ERRORED;
			reset();
		}
		jumpDist = 1;
		machineStatus = RUNNING;
		break;
	default:
		machineStatus = ERRORED; //Unknown instructions display error 
		break;
	}
	return jumpDist;
}

std::vector<long> GritVM::getDataMem(){

return dataMem;

}

STATUS GritVM::reset(){

dataMem.clear();
instructMem.clear();
accumulator =0;
machineStatus = WAITING;

return machineStatus;
}
