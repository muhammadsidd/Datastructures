#ifndef GRIT_VM_HPP
#define GRIT_VM_HPP
#include"GritVMBase.hpp"
#include <vector>
#include <list>
#include <fstream>
#include <iostream>
#include<string>

using namespace std;
using namespace GVMHelper; 
class GritVM : public GritVMInterface {

private: 

std::vector<long> dataMem;
std::list<Instruction> instructMem;
std::list<Instruction>::iterator currentInstruct;
STATUS machineStatus;
long accumulator;

public:
GritVM();
STATUS load(const std:: string filename, const std::vector<long>&initialMemory);
STATUS run();
long evaluate(Instruction _ins); 
std::vector<long> getDataMem();
STATUS reset();
};
#endif 