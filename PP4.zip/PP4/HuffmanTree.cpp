#include "HuffmanTree.hpp"

void HuffmanTree::postOrder(HuffmanNode * v)
{
	/*POSTORDER TRAVERSE */
		if(v->left != NULL){
		postOrder(v->left);
		}		//steer left if left is not null
		if(v->right != NULL){
		postOrder(v->right);
		}	//steer right if right is not null
		if (v->isLeaf()) {
			serializedStr += 'L';		//print L plus the element in the leaf if traverse goes left
			serializedStr += v->getCharacter();
		}
		else if (v->isBranch()) {
			serializedStr += 'B';		//print B for branch otherwise
		}
	
}

void HuffmanTree::encoding(HuffmanNode * v, string str)
{
	
	encoder.insert(pair<char, string>(v->getCharacter(), str));		//preorder inserting in the map -> first character map-> second is the recursive string 
	
	if(v->left != NULL){
		encoding(v->left, str + "0");		//recursively print out the prefix for the characters in the map
	}	//goes left print 0
	if(v->right != NULL){
		encoding(v->right, str + "1");		
	}	//goes right print 1
}

std::string HuffmanTree::compress(const std::string inputStr) {

	map<char, int> frequency;
	int count[200] ={0};		//breaking down the string one character at a time

	for (int i = 0; i < inputStr.length(); i++) { 
		char ch = inputStr.at(i);
		count[ch]++;			//store index as a charater int and value as the frequency 
	}
 
	for (int i = 0; i < 200; i++) { 
		if (count[i] != 0) {
			frequency.insert(pair<char, int>(i, count[i]));	//if frequency is not 0 insert the character and its frequency in the map
		}
	}

	for (auto iter = frequency.begin(); iter != frequency.end(); iter++) { 
		priorityQ.insert(new HuffmanNode(iter->first, iter->second));	//insert map into a min heap based priority queue
	}

	HuffmanNode *left, *right, *interm;

	 do { 

		left = priorityQ.min();
		priorityQ.removeMin();
		right = priorityQ.min();							
		priorityQ.removeMin();
		int sum = left->getFrequency() + right->getFrequency();		//left + right will be the parent node of the characters in the priority queue
		interm = new HuffmanNode('\0', sum, nullptr, left, right);	//make parent node and insert it into the pqueue
		priorityQ.insert(interm);		

	} while (priorityQ.size() != 1);	//do this until only one element remains in the pqueue

	encoding(priorityQ.min(), ""); 	//encode the string using 0s and 1s
	string str;
	
	
	for (int i = 0; i < inputStr.length(); i++) { 
		char c = inputStr.at(i);
		str += encoder[c];
	}
	//edited string with 0s and 1s 
	
	postOrder(priorityQ.min()); 
	delete priorityQ.min(); //delete the root node when done 
	return str;
}



std::string HuffmanTree::serializeTree() const {
	return serializedStr;
}



std::string HuffmanTree::decompress(const std::string inputCode, const std::string serializedTree) {
	 string decompressedStr; //string to be decompressed
	stack<HuffmanNode*> Stack; //declare a stack for the serialized string 
	HuffmanNode *left, *right, *intermediate;	

	for (int i = 1; i < serializedTree.length(); i++) {
		
		
		if ((serializedTree.at(i) == 'B' && serializedTree.at(i - 1) != 'L') || 
		(serializedTree.at(i) == 'B' && serializedTree.at(i - 1) == 'L' && serializedTree.at(i - 2) == 'L')) {
			right = Stack.top();
			Stack.pop();
			left = Stack.top();
			Stack.pop();
			intermediate = new HuffmanNode('#', 1, nullptr, left, right);
			Stack.push(intermediate);
		}
		
		
		if (serializedTree.at(i-1) == 'L') {
			if (serializedTree.at(i) == 'B' && serializedTree.at(i - 1) == 'L' && serializedTree.at(i - 2) == 'L') {
				continue;
			}
			else {
				Stack.push(new HuffmanNode(serializedTree.at(i), 1));
			}
		}
	}
	HuffmanNode *Top = Stack.top();
	HuffmanNode *u = Top;
	

	for (int i = 0; i < inputCode.length(); i++) {
		char temp = inputCode.at(i);

		if (temp == '0') {
			u = u->left;
		}

		if (temp == '1') {
			u = u->right;
		}

		if (u->isLeaf()) {
			decompressedStr += u->getCharacter();
			u = Top;
		}
	}
	return decompressedStr;
}





