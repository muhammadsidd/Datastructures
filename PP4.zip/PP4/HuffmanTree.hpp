#ifndef HUFFMAN_H
#define HUFFMAN_H

#include "HuffmanBase.hpp"
#include "HeapQueue.hpp"
#include <map>
#include <stack>
using namespace std;

class HuffmanTree : public HuffmanTreeBase {
public:
	std::string compress(const std::string inputStr);
	std::string serializeTree() const;
	std::string decompress(const std::string inputCode, const std::string serializedTree);
	void deallocatingHeap(HuffmanNode* node);
	void encoding(HuffmanNode* root, string str);
	void postOrder(HuffmanNode* tempNodes);

private:
	map<char, string> encoder; //Stores the characters and there frequency
	HeapQueue<HuffmanNode*, HuffmanNode::Compare> priorityQ; //Priority Queue that stores the min heap first and then the modified tree
	string serializedStr; //I declared the serialized string here, because I wanted to have access to it even if it was modified anywhere outside the serializeTree method
};

#endif /* HUFFMAN_H */